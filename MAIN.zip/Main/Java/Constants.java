
public class Constants {
	public static final int SYNCHMODE_SYNCH = 0;
	public static final int SYNCHMODE_ASYNCH = 1;
	public static final int DISPLAYMODE_IDLE = 0;
	public static final int DISPLAYMODE_MOVIE = 1;
	public static final int DISCONNECT = 2;
}
